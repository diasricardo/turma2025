const documentacao = {
    openapi: '3.0.3',
    info:{
        title: 'API de Ordem de Serviços',
        description: 'Documentação da API de ordens de serviço',
        version: '1.0.0'
    },
    servers: [
        {url: 'http://localhost:3000', description: 'Localhost'}
    ],
    tags:[
        {name: 'Usuários', description: 'Operações relacionadas a usuarios'},
        {name: 'Departamentos', description: 'Operações relacionadas a departamentos'}
    ],
    paths: {
        "/usuarios": {
            get: {
                tags:["Usuários"],
                summary: "Listar todos usuários",
                responses:{
                    200:{
                        description: "Dados obtidos com sucesso!",
                        content:{
                            "apllication/json": {
                                schema:{
                                    type: "array",
                                    items: {$ref: '#/components/schemas/Listar_Usuarios'}
                                }
                            }
                        }
                    },
                    500:{
                        
                    }
                }
            }
        },
        "departamentos":{

        }
    },
    components:{
        schemas:{
            Listar_Usuarios:{
                type: 'object',
                properties: {
                    id: {type: "integer", example: 1},
                    nome: {type: "string", example: "Ricardo"},
                    email: {type: "string", example: "ricardo@email.com"}
                }
            },
            Listar_Departamentos: {

            }
        }
    }
}

export default documentacao