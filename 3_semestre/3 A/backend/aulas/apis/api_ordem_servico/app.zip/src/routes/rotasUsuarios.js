import { Router } from "express";
import { BD } from "../../db.js";

const router = Router();

//Endpoint para listar todos os usuários
router.get('/usuarios', async(req, res) =>{
    try{
        // criar uma variavel para enviar o comando sql
        const comando = `SELECT * FROM usuarios`
        //criar uma variavel para receber o retorno do sql
        const usuarios = await BD.query(comando)
        res.status(200).json(usuarios.rows)
    }
    catch(error){
        console.error('Erro ao listar usuários', error.message);
        res.status(500).json({error: 'Erro ao listar usuários'});
    }
})

router.post('/usuarios', async(req, res) => {
    const nome = req.body.nome;
    const email = req.body.email;
    const senha = req.body.senha;

    try{
        const comando = `INSERT INTO TESTE(nome, email, senha)
                        VALUES('${nome}','${email}', '${senha}')`
        console.log(comando);
        await BD.query(comando)
        res.status(201).json("Usuário cadastrado com sucesso!");
    }catch(error){
        console.error('Erro ao cadastrar usuario', error.message);
        res.status(500).json({error: 'Erro ao cadastrar usuario'})
    }
})


export default router