import Aula01 from "./pages/Aula01";
import Aula02 from "./pages/Aula02";

export default function App(){
  return(
    <div>
      <Aula01 />
      <Aula02 />
    </div>
    
  )
  
}