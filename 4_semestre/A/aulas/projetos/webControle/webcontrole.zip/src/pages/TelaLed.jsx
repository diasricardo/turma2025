export default function TelaLed(){
    return(
        <div>
            <h2 className="text-xl font-bold mb-4">Controle de LED</h2>

        </div>
    )
}